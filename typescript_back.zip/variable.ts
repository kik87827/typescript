let vname :string = "kim";
let age :number = 50;
let merryIs :boolean = true;

let memberArrays :string[] = ['kim','park'];
let memberArrays2 :number[] = [1,2];

let memberObjs :{ member1 : string, member2 :string } = { member1 : 'kim', member2 : 'park'}
let memberObjs2 :{ [key:string] : string } = { member1 : 'kim2', member2 : 'park2'}

let test22 :string = 'park';