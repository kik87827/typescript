const namekk: string = 'kim';
let agekk: number = 50;
let merrykkIs: boolean = true;
let membersk :string[] = ['kim', 'park'];
let membersk2: { name: string, member2: string } = { name: 'kkk', member2: 'park' }
let membersk3 = 123;