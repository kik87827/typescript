class PersonType {
    constructor(public name :string){

    }
}

let childInstance = new PersonType('kim');
console.log(childInstance);