let indexName: string = "kim";
let indexAge: number = 50;
let indexMerry: boolean = false;
let indexMerry2: undefined = undefined;

let indexMember: string[] = ["kim", "park"];
let indexNumber: number[] = [5, 12];

let indexMemberObj: { member1: string; member2: string } = {
  member1: "kim",
  member2: "park",
};
