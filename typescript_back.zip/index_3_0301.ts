let member3kk: (number | string | boolean) = 123; // union
member3kk= 'string';

let member3kk2 :(number | string)[] = [1,'2',3]
let member3kk3: { a: (string | number) } = { a: '123' }

let memberkkk: any;
memberkkk = 123;
memberkkk = true;
memberkkk = 'sdfs';

let memberkkk2: unknown;

memberkkk2 = 123;
memberkkk2 = '123';
memberkkk2 = { key: '123' };

/* let var1: string = memberkkk2; */
/* memberkkk2 - 1 */

let testage: string | number;

/* testage + 1; */