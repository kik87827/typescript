class Person2 {
  name :string;
  age :number;
  constructor(a) {
    this.name = a;
    this.age = 20;
  }
}
